# Google-Keep-Clone
This is a simple Note Taking Application Whose design is inspired from Google Keep and created using Vanilla Javascript and Local Storage.
